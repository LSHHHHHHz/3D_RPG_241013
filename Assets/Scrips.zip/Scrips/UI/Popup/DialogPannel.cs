using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;
public class DialogPannel : MonoBehaviour
{
    public Image dialongPannel;
    public Text dialogText;
    public GameObject cursorObject;
}
