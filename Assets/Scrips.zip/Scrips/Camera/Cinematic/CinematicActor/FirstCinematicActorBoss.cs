using System.Collections;
using UnityEngine;

public class FirstCinematicActorBoss : CinematicActor
{
    public override void PerformAction()
    {
        Debug.Log("�ǳ�");
    }
}
