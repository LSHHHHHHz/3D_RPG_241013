using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActSkill1Projectile : MonoBehaviour
{
    public EffectTrigger[] effectTrigger;
}
