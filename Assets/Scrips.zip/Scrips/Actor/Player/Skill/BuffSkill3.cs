using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class BuffSkill3 : BaseSkill
{
    public override void ExcuteSkill(Actor actor)
    {

    }
}
