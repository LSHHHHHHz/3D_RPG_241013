using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
public class PlayerEquipment : MonoBehaviour
{
    public string weaponEquipID; 
    public string shieldEquipID;  

}
