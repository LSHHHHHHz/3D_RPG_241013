
public interface IEvent
{
    void SendEvent(IEventReceiver eventReceiver);
}
