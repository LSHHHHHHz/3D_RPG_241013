
public interface IEventReceiver
{
   void ReceiveEvent(IEvent ievent);
}
