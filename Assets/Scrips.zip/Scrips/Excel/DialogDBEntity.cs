using System;

[Serializable]
public class DialogDBEntity
{
    public int branch;
    public string name;
    public string dialog;
}
