using System;

[Serializable]
public class ShopDB
{
    public string npcID;
    public string dataID;
}
